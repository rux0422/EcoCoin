import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, ImageBackground } from 'react-native';
import { AntDesign, Ionicons } from '@expo/vector-icons'; // Import the Google logo icon and Ionicons

import * as Google from 'expo-google-app-auth';

const YourComponent = () => {
  return (
    <ImageBackground
      source={{ uri: 'https://images.pexels.com/photos/4042621/pexels-photo-4042621.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load' }}
      style={styles.backgroundImage}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.containerFluid}>
          <View style={styles.row}>
            <View style={styles.imageContainer}>
              <Ionicons name="leaf" size={32} color="white" />
              <Text style={styles.heading}>EcoCoin</Text>
              <Text style={styles.subHeading}>An incentivised method to go GREEN!!</Text>
            </View>
            <View style={styles.formContainer}>
              <View style={styles.divider}>
                <Text style={styles.dividerText}>Sign in with</Text>
              </View>
              <View style={styles.socialButtons}>
                {/* Use the Google logo icon as a button */}
                <TouchableOpacity style={[styles.socialButton, { backgroundColor: 'green' }]}>
                  <AntDesign name="google" size={24} color="white" />
                </TouchableOpacity>
              </View>
              <View style={styles.form}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your email"
                />
                <TextInput
                  style={styles.input}
                  placeholder="Enter password"
                  secureTextEntry
                />
                <TouchableOpacity style={[styles.button, { backgroundColor: 'green' }]}>
                  <Text style={styles.buttonText}>Login</Text>
                </TouchableOpacity>
                <Text style={[styles.registerText, { color: 'white' }]}>Don't have an account? <Text style={[styles.registerLink, { color: 'white' }]}>Register</Text></Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
    paddingBottom: 20,
  },
  containerFluid: {
    width: '100%',
    paddingHorizontal: 20,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  imageContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 5,
  },
  subHeading: {
    fontSize: 12,
    color: 'white',
    marginBottom: 20,
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  formContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
    marginTop: 20,
  },
  divider: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  dividerText: {
    fontWeight: 'bold',
    marginHorizontal: 5,
    color: 'white',
  },
  socialButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  socialButton: {
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginHorizontal: 5,
  },
  form: {
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    width: '100%',
    backgroundColor: 'white',
  },
  button: {
    borderRadius: 5,
    padding: 10,
    alignItems: 'center',
    width: '100%',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  registerText: {
    textAlign: 'center',
    marginBottom: 20,
  },
  registerLink: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default YourComponent;


